<div class="alert_neutral pad15 brad10 bmargin5 centered_element text_small">
	<?php echo $lang['priv_off']; ?>
</div>