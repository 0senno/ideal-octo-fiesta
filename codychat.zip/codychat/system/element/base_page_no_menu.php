<div id="page_content">
	<div id="page_global">
		<div class="page_indata">
			<div id="page_wrapper">
				<?php echo $boom; ?>
			</div>
		</div>
	</div>
</div>