<div class="avheader">
	<div class="avtop btable bhead topcard avbackground">
		<div class="bcell_mid">
			<div class="avtopmenu btable">
				<div class="bcell_mid">
					<div class="btable">
						<div class="bcell">
							<div id="clevel" class="lite_olay clevel_item clevel">
								<img src="<?php echo levelIcon(); ?>"/> <span class="clevel_count"></span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="btable avavpart">
				<div class="bcell_mid">
				</div>
				<div class="bcell_mid avtop_content brelative">
					<img class="avavatar"  src=""/>
				</div>
				<div class="bcell_mid">
				</div>
			</div>
			<div class="btable avdetails">
				<p class="avusername cover_text bellips"></p>
				<p class="gentext cover_text text_small bellips"></p>
			</div>
			<div class="btable tpad3">
				<div class="bcell_mid avtopopt">
					<img class="avflag" src=""/>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="avself card_menu back_menu bottomcard">
	<div data="" value="" data-av="" class="avset bmenu avitem get_info">
		<i class="fa fa-circle-user default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem" onclick="editProfile();">
		<i class="fa fa-edit theme_color"></i> <?php echo $lang['edit']; ?>
	</div>
</div>
<div class="avbot card_menu back_menu bottomcard">
	<div data="" value="" data-av="" class="avset bmenu avitem get_info">
		<i class="fa fa-circle-user default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avpriv bmenu avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private']; ?>
	</div>
</div>
<div class="avstaff card_menu back_menu bottomcard">
	<div data="" value="" data-av="" class="avset bmenu avitem get_info">
		<i class="fa fa-circle-user default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avpriv bmenu avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private_chat']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem opencall avcall">
		<i class="fa fa-phone success"></i> <?php echo $lang['call']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem get_actions avactions">
		<i class="fa fa-check error"></i> <?php echo $lang['action']; ?>
	</div>
</div>
<div class="avroomstaff card_menu back_menu bottomcard">
	<div data="" value="" data-av="" class="avset bmenu avitem get_info">
		<i class="fa fa-circle-user default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avpriv bmenu avitem gprivate ">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private_chat']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem opencall avcall">
		<i class="fa fa-phone success"></i> <?php echo $lang['call']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem get_actions avactions">
		<i class="fa fa-check error"></i> <?php echo $lang['action']; ?>
	</div>
</div>
<div class="avother card_menu back_menu bottomcard">
	<div data="" value="" data-av="" class="avset bmenu avitem get_info">
		<i class="fa fa-circle-user default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avpriv bmenu avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem opencall avcall">
		<i class="fa fa-phone success"></i> <?php echo $lang['call']; ?>
	</div>
	<div data="" value="" data-av="" class="avset bmenu avitem get_actions avactions">
		<i class="fa fa-check error"></i> <?php echo $lang['action']; ?>
	</div>
</div>