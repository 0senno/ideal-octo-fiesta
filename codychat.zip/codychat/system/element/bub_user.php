<p onclick="getProfile(<?php echo $boom['user_id']; ?>);" class="bubtext">
	<?php echo $boom['user_name']; ?>
</p> 