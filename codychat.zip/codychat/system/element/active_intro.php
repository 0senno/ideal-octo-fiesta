<div class="active_user">
	<img alt="<?php echo $boom['user_name']; ?>" title="<?php echo $boom['user_name']; ?>" class="lazy active_avatar" data-src="<?php echo myAvatar($boom['user_tumb']); ?>" src="<?php echo imgLoader(); ?>"/>
</div>