<?php
require('../config.php');
?>
<div class="modal_content">
	<div class="text_box">
		<?php echo loadPageData('terms_of_use'); ?>
	</div>
</div>