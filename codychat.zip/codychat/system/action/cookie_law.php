<?php
require('../config.php');
setBoomCookieLaw();
?>