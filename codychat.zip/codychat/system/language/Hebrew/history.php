<?php
$hlang['flood_mute'] = 'מציף הושתק';
$hlang['word_mute'] = 'מילה הושתקה';
$hlang['word_kick'] = 'מילה נזרקה';
$hlang['spam_mute'] = 'ספאם הושתק';
$hlang['spam_ghost'] = 'Spam ghost';
$hlang['spam_ban'] = 'סאפם נחסם';
$hlang['mute'] = 'השתקה';
$hlang['ban'] = 'חסימה';
$hlang['kick'] = 'לבעוט';
$hlang['flood_kick'] = 'Flood kick';
$hlang['vpn_kick'] = 'Vpn kick';
$hlang['main_mute'] = 'Main mute';
$hlang['private_mute'] = 'Private mute';
$hlang['ghost'] = 'Ghost';
$hlang['warn'] = 'Warning';
?>