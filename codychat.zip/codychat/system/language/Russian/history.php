<?php
$hlang['flood_mute'] = 'Флуд кляп';
$hlang['word_mute'] = 'Мат кляп';
$hlang['word_kick'] = 'Мат кик';
$hlang['spam_mute'] = 'Спам кляп';
$hlang['spam_ghost'] = 'Спам-призрак';
$hlang['spam_ban'] = 'Спам бан';
$hlang['mute'] = 'Кляп';
$hlang['ban'] = 'Бан';
$hlang['kick'] = 'Кик';
$hlang['flood_kick'] = 'Удар наводнения';
$hlang['vpn_kick'] = 'впн удар';
$hlang['main_mute'] = 'Основной звук';
$hlang['private_mute'] = 'Частный звук';
$hlang['ghost'] = 'Призрак';
$hlang['warn'] = 'Warning';
?>