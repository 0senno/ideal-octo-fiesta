<?php
$hlang['flood_mute'] = 'Inundação silenciosa';
$hlang['word_mute'] = 'Palavra muda';
$hlang['word_kick'] = 'Chute de palavra';
$hlang['spam_mute'] = 'Spam Mudo';
$hlang['spam_ghost'] = 'Fantasma de spam';
$hlang['spam_ban'] = 'Proibição de spam';
$hlang['mute'] = 'Mudo';
$hlang['ban'] = 'Proibição';
$hlang['kick'] = 'Kick';
$hlang['flood_kick'] = 'Chute de inundação';
$hlang['vpn_kick'] = 'Vpn kick';
$hlang['main_mute'] = 'Mudo principal';
$hlang['private_mute'] = 'Mudo privado';
$hlang['ghost'] = 'Fantasma';
$hlang['warn'] = 'Warning';
?>