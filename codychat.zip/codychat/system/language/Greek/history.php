<?php
$hlang['flood_mute'] = 'Σίγαση Flood';
$hlang['word_mute'] = 'Σίγαση λέξης';
$hlang['word_kick'] = 'Κ Λέξης';
$hlang['spam_mute'] = 'Σίγαση Spam';
$hlang['spam_ghost'] = 'Spam Φάντασμα';
$hlang['spam_ban'] = 'Απαγόρευση spam';
$hlang['mute'] = 'Σίγαση';
$hlang['ban'] = 'Απαγόρευση';
$hlang['kick'] = 'Αποβολή';
$hlang['flood_kick'] = 'Αποβολή Flood';
$hlang['vpn_kick'] = 'Αποβολή VPN';
$hlang['main_mute'] = 'Σίγαση δωματίου';
$hlang['private_mute'] = 'Ιδιωτική σίγαση';
$hlang['ghost'] = 'Φάντασμα';
$hlang['warn'] = 'Warning';
?>
