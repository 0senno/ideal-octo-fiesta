<?php
$hlang['flood_mute'] = 'كتم الفيضان';
$hlang['word_mute'] = 'كلمة الكتم';
$hlang['word_kick'] = 'كلمة الطرد';
$hlang['spam_mute'] = 'كتم البريد المزعج';
$hlang['spam_ghost'] = 'شبح الرسائل المزعجة';
$hlang['spam_ban'] = 'حظر البريد المزعج';
$hlang['mute'] = 'كتم';
$hlang['ban'] = 'حظر';
$hlang['kick'] = 'طرد';
$hlang['flood_kick'] = 'طرد الفيضان';
$hlang['vpn_kick'] = 'طرد Vpn';
$hlang['main_mute'] = 'كتم الرئيسي';
$hlang['private_mute'] = 'كتم الخاص';
$hlang['ghost'] = 'شبح';
$hlang['warn'] = 'Warning';
?>