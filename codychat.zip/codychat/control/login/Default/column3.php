<div id="col3_section">
	<div class="col3_container">
		<div class="col3_element">
			<img src="control/login/Default/images/community.png" alt="Image 2">
			<div class="col3_text">
				<p class="col3_title">Active community</p>
				<p>Share and talk with other customers by joining our store chat. Get tips and help from people who trust our products for years.</p>
			</div>
		</div>
		<div class="col3_element">
			<img src="control/login/Default/images/responsive.png" alt="Image 2">
			<div class="col3_text">
				<p class="col3_title">Responsive design</p>
				<p>Desktop computer, mobile or tablet no problem. Codychat is fully responsive on all device type and support all major browsers.</p>
			</div>
		</div>
		<div class="col3_element">
			<img src="control/login/Default/images/code.png" alt="Image 2">
			<div class="col3_text">
				<p class="col3_title">Trusted codes</p>
				<p>Trusted by 1000's chat sites around the globe. Codychat offer one of the most bugfree experience on the market.</p>
			</div>
		</div>
	</div>
</div>